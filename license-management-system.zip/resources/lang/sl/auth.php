<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Te poverilnice se ne ujemajo z našo evidenco.',
    'password' => 'Navedeno geslo ni pravilno.',
    'throttle' => 'Preveč poskusov prijave. Poskusite ponovno čez :seconds sekund.',
];
